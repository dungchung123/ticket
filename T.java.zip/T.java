/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 *
 * @author checongtam
 */
public class T extends Application {
    @Override
    public void start(Stage Stage) {
       
       Stage.setWidth(150);
        Stage.setHeight(200);
        Button bt1=new Button();
        Button bt2=new Button();
        Button bt3=new Button();
        Button bt4=new Button();
        Button bt5=new Button();
        Button bt6=new Button();
        Button bt7=new Button();
        bt1.setPrefSize(50, 50);
        bt2.setPrefSize(50, 50);
        bt3.setPrefSize(50, 50);
        bt4.setPrefSize(50, 50);
        bt5.setPrefSize(50, 50);
        bt6.setPrefSize(50, 50);
        bt7.setPrefSize(50, 50);
        bt1.setBackground(new Background(new BackgroundFill(Color.rgb(0, 80, 80, 0.7), new CornerRadii(5.0),new javafx.geometry.Insets(-5.0))));
        bt2.setBackground(new Background(new BackgroundFill(Color.rgb(0, 80, 80, 0.7), new CornerRadii(5.0),new javafx.geometry.Insets(-5.0))));
        bt3.setBackground(new Background(new BackgroundFill(Color.rgb(0, 80, 80, 0.7), new CornerRadii(5.0),new javafx.geometry.Insets(-5.0))));
        bt4.setBackground(new Background(new BackgroundFill(Color.rgb(0, 80, 80, 0.7), new CornerRadii(5.0),new javafx.geometry.Insets(-5.0))));
        bt5.setBackground(new Background(new BackgroundFill(Color.rgb(0, 80, 80, 0.7), new CornerRadii(5.0),new javafx.geometry.Insets(-5.0))));
        bt6.setBackground(new Background(new BackgroundFill(Color.rgb(0, 80, 80, 0.7), new CornerRadii(5.0),new javafx.geometry.Insets(-5.0))));
        bt7.setBackground(new Background(new BackgroundFill(Color.rgb(0, 80, 80, 0.7), new CornerRadii(5.0),new javafx.geometry.Insets(-5.0))));
        GridPane gp=new GridPane();
        gp.setConstraints(bt1,0,0);
        gp.setConstraints(bt2,1,0);
        gp.setConstraints(bt3,2,0);
        gp.setConstraints(bt4,1,1);
        gp.setConstraints(bt5,1,2);
        gp.setConstraints(bt6,1,3);
        gp.setConstraints(bt7,1,4);
        gp.getChildren().addAll(bt1,bt2,bt3,bt4,bt5,bt6,bt7);
        Scene scene = new Scene(gp);
		
		Stage.setScene(scene);
		
		Stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
